zlel_main module
=================

.. automodule:: zlel_main
   :members:
   :show-inheritance:
   :undoc-members:

Kodearen iturria:
-----------------

.. literalinclude:: ../../zlel_main.py
   :language: python
   :linenos:
